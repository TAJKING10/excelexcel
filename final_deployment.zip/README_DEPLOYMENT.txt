====================================
ADVENSYS PAIE - DEPLOYMENT GUIDE
====================================

Application: Luxembourg Payroll Management System
Version: 1.0.0
Build Date: 2025-10-30

====================================
DEPLOYMENT INSTRUCTIONS
====================================

1. UPLOAD FILES TO YOUR WEB SERVER
   --------------------------------
   - Upload ALL files and folders from this 'dist' directory to your web server
   - Recommended location: public_html/ or www/ or htdocs/
   - Make sure to upload the .htaccess file (it might be hidden)

2. SUPABASE CONFIGURATION
   -----------------------
   Your application is configured to use Supabase as the backend.

   Current Supabase URL: https://ozkgkgqahgwuwmohslsr.supabase.co

   IMPORTANT: The Supabase API key and URL are embedded in the JavaScript files.
   If you need to change these, you must rebuild the application with new values
   in the .env file.

3. FILE STRUCTURE
   --------------
   /index.html          - Main application entry point
   /.htaccess           - Apache configuration for React Router
   /assets/             - CSS, JavaScript, and other assets
   /README_DEPLOYMENT.txt - This file

4. SERVER REQUIREMENTS
   -------------------
   - Apache web server with mod_rewrite enabled
   - PHP not required (this is a static React application)
   - HTTPS recommended for security (especially for authentication)

5. TESTING THE DEPLOYMENT
   -----------------------
   After uploading, test the following:

   a) Navigate to your website URL
   b) You should see the login page
   c) Test login with demo credentials:
      - Username: admin
      - Password: admin

   d) Test navigation:
      - Click on different menu items
      - Refresh the page (should not show 404)
      - Use browser back/forward buttons

6. TROUBLESHOOTING
   ---------------

   Problem: "404 Not Found" when refreshing the page
   Solution: Make sure .htaccess file is uploaded and mod_rewrite is enabled

   Problem: "Cannot connect to database"
   Solution: Check Supabase configuration and ensure the service is active

   Problem: Blank white screen
   Solution: Check browser console (F12) for errors. Ensure all files uploaded correctly.

   Problem: CSS not loading
   Solution: Clear browser cache and check if /assets/ folder uploaded correctly

7. SECURITY RECOMMENDATIONS
   ------------------------
   - Enable HTTPS on your domain
   - Configure CORS settings in Supabase to allow only your domain
   - Regularly update Supabase security rules
   - Monitor access logs for suspicious activity
   - Keep regular backups of your Supabase database

8. PERFORMANCE OPTIMIZATION
   -------------------------
   - The .htaccess file includes GZIP compression
   - Browser caching is configured for optimal performance
   - Assets are minified and optimized

9. SUPPORT & DOCUMENTATION
   ------------------------
   For issues or questions:
   - Check Supabase documentation: https://supabase.com/docs
   - Review application logs in Supabase dashboard
   - Contact your system administrator

====================================
DEFAULT LOGIN CREDENTIALS
====================================

SUPER ADMIN:
- Username: admin
- Password: admin

IMPORTANT: Change these credentials immediately after first login!

====================================
FEATURES INCLUDED
====================================

✓ Employee Management
✓ Company Management
✓ Individual Freelancer Management
✓ Monthly Payslip Generation
✓ Annual Payslip Generation
✓ Luxembourg Tax Calculations (2025 barème)
✓ PDF Export (Monthly & Annual)
✓ User Access Control
✓ Activity Logging
✓ Payslip History Tracking
✓ Multi-language Support (FR/EN)
✓ Analytics & Reports

====================================
TAX CALCULATIONS
====================================

The application uses Luxembourg 2025 tax regulations:

Social Contributions:
- Assurance Maladie: 2.80%
- Majoration Espèce: 0.25%
- Assurance Pension: 8.00%
- Assurance Dépendance: 1.40%

Tax Classes Supported:
- Class 1: Single
- Class 1A: Single with children
- Class 2: Married/Partnership

All calculations are verified against official Luxembourg barème 2025.

====================================
MAINTENANCE
====================================

Regular maintenance tasks:
1. Monitor Supabase usage and storage
2. Review user access logs monthly
3. Backup Supabase database weekly
4. Update tax rates when regulations change
5. Test payslip calculations quarterly

====================================
END OF DEPLOYMENT GUIDE
====================================

Deployed successfully! Your Luxembourg Payroll Management System is ready to use.

For technical support or customization requests, contact your development team.
