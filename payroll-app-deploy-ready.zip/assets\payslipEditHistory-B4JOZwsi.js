import{s as o}from"./index-D9xlXdFV.js";async function f(a,s,e,t,i){const r=(await o.auth.getUser()).data.user;if(!r)throw new Error("User not authenticated");const p=[];e&&t&&Object.keys(t).forEach(d=>{JSON.stringify(e[d])!==JSON.stringify(t[d])&&p.push(d)});const y={payslip_id:a,payslip_type:s,edited_by:r.id,edited_at:new Date().toISOString(),changes:{oldValues:e,newValues:t,changedFields:p},comment:i||null},{error:n}=await o.from("payslip_edit_history").insert(y);if(n)throw n}async function l(a,s){const{data:e,error:t}=await o.from("payslip_edit_history").select(`
      *,
      profiles:edited_by (
        id,
        first_name,
        last_name,
        email
      )
    `).eq("payslip_id",a).eq("payslip_type",s).order("edited_at",{ascending:!1});if(t)throw t;return(e||[]).map(i=>{var r;return{id:i.id,payslipId:i.payslip_id,payslipType:i.payslip_type,editedBy:i.edited_by,editedAt:i.edited_at,changes:i.changes,comment:i.comment,editorName:i.profiles?`${i.profiles.first_name||""} ${i.profiles.last_name||""}`.trim():"Unknown",editorEmail:((r=i.profiles)==null?void 0:r.email)||""}})}export{l as getPayslipEditHistory,f as recordPayslipEdit};
